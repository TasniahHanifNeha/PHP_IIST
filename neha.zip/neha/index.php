<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <?php wp_head();?>
</head>
<body>
<!-- ========logo========= -->
<header class="header container-fluid">
    <div class="logo row">
        <div class="col-lg-6">
            <?php the_custom_logo();?>
        </div>
        <div class="col-lg-6 text-end">
            <?php dynamic_sidebar('right_logo');?>
        </div>
    </div>
</header>


<!-- =======slider======= -->

<div class="container-fluid slider">
<div id="carouselExample" class="carousel slide">
  <div class="carousel-inner">
  <?php
    $x = 0;
    while(have_posts()){the_post();
    $x++;
    ?>
    <div class="carousel-item <?=($x==1)? 'active': '' ?>">
        <?php the_post_thumbnail();?>
    </div>
    <?php }?>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</div>

<!-- ======menu====== -->

<div class="container menu navbar-expand d-flex justify-content-center">
    <?php wp_nav_menu(array(
        'theme_location'=>'TM',
    ));
    ?>
</div>


<!-- =======hero======== -->

<div class="container text-center">
    <div class="row hero-top text-center">
        <?php dynamic_sidebar('hero-top'); ?>
    </div>

    <div class="row hero-bottom">
        <div class="col-lg-4">
            <div class="card" style="width: 18rem;">
            <?php dynamic_sidebar('hero-b-img'); ?>
            <div class="card-body">
            <?php dynamic_sidebar('hero-b-body'); ?>
            </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="card" style="width: 18rem;">
            <?php dynamic_sidebar('hero-b-img2'); ?>
            <div class="card-body">
            <?php dynamic_sidebar('hero-b-body2'); ?>
            </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="card" style="width: 18rem;">
            <?php dynamic_sidebar('hero-b-img3'); ?>
            <div class="card-body">
            <?php dynamic_sidebar('hero-b-body3'); ?>
            </div>
            </div>
        </div>
    </div>
</div>

<!-- ==========photo-frame========= -->

<div class="container pt-5 pb-5">
    <div class="row">
        <div class="col-lg-4">
            <img src="<?= get_template_directory_uri() ?>./assets/images/green1.png" alt="">
        </div>
        <div class="col-lg-4 text-center">
            <h4>Recent Photos</h4>
            <p>Lorem ipsum dolor sit amet.</p>
        </div>
        <div class="col-lg-4">
            <img src="<?= get_template_directory_uri() ?>./assets/images/green2.png" alt="">
        </div>
    </div>


    <div class="row">
        <div class="col-lg-3">
            <div class="card" style="width: 18rem;">
            <?php dynamic_sidebar('photo-img'); ?>
            <div class="card-body">
            <?php dynamic_sidebar('photo-body'); ?>
            </div>
            </div>
        </div>

        <div class="col-lg-3">
            <div class="card" style="width: 18rem;">
            <?php dynamic_sidebar('photo-img2'); ?>
            <div class="card-body">
            <?php dynamic_sidebar('photo-body2'); ?>
            </div>
            </div>
        </div>

        <div class="col-lg-3">
            <div class="card" style="width: 18rem;">
            <?php dynamic_sidebar('photo-img3'); ?>
            <div class="card-body">
            <?php dynamic_sidebar('photo-body3'); ?>
            </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-4">
            <img src="<?= get_template_directory_uri() ?>./assets/images/green1.png" alt="">
        </div>
        <div class="col-lg-4 text-center">
            <h4>Recent Photos</h4>
            <p>Lorem ipsum dolor sit amet.</p>
        </div>
        <div class="col-lg-4">
            <img src="<?= get_template_directory_uri() ?>./assets/images/green2.png" alt="">
        </div>
    </div>
    <div class="row">
    <div class="container-fluid">
<div id="carouselExample" class="carousel slide">
    <?php
    $qry = new WP_Query([
        'post_type'=>'post',
        'category_name'=>'slider'
    ]);
    ?>
  <div class="carousel-inner">
  <?php
    $x = 0;
    while($qry->have_posts()){$qry->the_post();
    $x++;
    ?>
    <div class="carousel-item <?=($x==1)? 'active': '' ?>">
        <?php the_title();?>
    </div>
    <?php }?>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</div>
    </div>
</div>

<!-- ===========text-slider========== -->





<!-- ============footer========== -->

<footer class="footer mt-5">
    <div class="row top-footer">
        <div class="col-lg-6 l-footer">
            <ul>
                <h4>CONTACT US</h4>
                <li><a href="">Address: Office of the Project Director Padma Multipurpose Bridge Project</a></li>
                <li><a href="">4th floor, Setu Bhaban, New Airport Road, Banani, Dhaka-1212</a></li>
                <li><a href="">Telephone: +880 2 55040451</a></li>
                <li><a href=""></a>Fax: +880 2 55040477</li>
                <li><a href="">Email: padmabridgeweb@gmail.com</a></li>
            </ul>
        </div>

        <div class="col-lg-6 r-footer">
            <ul>
                <h4>IMPORTANT LINKS</h4>
                <li><a href="">Prime Minister's Office</a></li>
                <li><a href="">PMIS</a></li>
                <li><a href="">Bangladesh Bridge Authority</a></li>
                <li><a href="">Bridges Division</a></li>
                <li><a href="">Roads and Highways Department</a></li>
                <li><a href="">Cabinet Division</a></li>
                <li><a href="">Ministry of Public Administration</a></li>
                <li><a href="">National Web Portal</a></li>
            </ul>
        </div>
    </div>
    <div class="row bottom-footer">
        <div class="col-sm-6">
        <p>POWERED BY SOLUTION ART LTD</p>
        </div>
        <div class="col-sm-6 text-end">
        <p>COPYRIGHT © 2015. BANGLADESH BRIDGE AUTHORITY.</p>
        </div>
    </div>
    </div>
</footer>






















<?php wp_footer();?>
</body>
</html>