<?php
wp_enqueue_style( 'style-name', get_stylesheet_uri() );
wp_enqueue_style( 'style-bootstrap', get_template_directory_uri() . './assets/css/bootstrap.min.css');

wp_enqueue_script( 'script-name', get_template_directory_uri() . './assets/js/bootstrap.bundle.min.js', array(), '1.0.0', true );


add_theme_support('title-tag');
add_theme_support('custom-logo');
add_theme_support('post-thumbnails');

register_sidebar(array(
    'name'=>'Top Right Logo',
    'id'=>'right_logo',
    'after_widget'=> '',
	'after_widget'=> '',
));

// =======menu========

register_nav_menus(array(
    'TM'=>'Primary',
));

// ===hero-top====

register_sidebar(array (
    'name'=> 'Hero Top',
    'id'=> 'hero-top',
    'before_widget'=> '',
    'after_widget'=> ''
));

// ====card====
register_sidebar(array (
    'name'=> 'Hero Bottom Img',
    'id'=> 'hero-b-img',
    'before_widget'=> '',
    'after_widget'=> ''
));
register_sidebar(array (
    'name'=> 'Hero Bottom Body',
    'id'=> 'hero-b-body',
    'before_widget'=> '',
    'after_widget'=> ''
));
// =========
register_sidebar(array (
    'name'=> 'Hero Bottom Img2',
    'id'=> 'hero-b-img2',
    'before_widget'=> '',
    'after_widget'=> ''
));
register_sidebar(array (
    'name'=> 'Hero Bottom Body2',
    'id'=> 'hero-b-body2',
    'before_widget'=> '',
    'after_widget'=> ''
));
// ======
register_sidebar(array (
    'name'=> 'Hero Bottom Img3',
    'id'=> 'hero-b-img3',
    'before_widget'=> '',
    'after_widget'=> ''
));
register_sidebar(array (
    'name'=> 'Hero Bottom Body3',
    'id'=> 'hero-b-body3',
    'before_widget'=> '',
    'after_widget'=> ''
));
// ====photo===

register_sidebar(array (
    'name'=> 'Photo Img',
    'id'=> 'photo-img',
    'before_widget'=> '',
    'after_widget'=> ''
));
register_sidebar(array (
    'name'=> 'Photo Body',
    'id'=> 'photo-body',
    'before_widget'=> '',
    'after_widget'=> ''
));

register_sidebar(array (
    'name'=> 'Photo Img2',
    'id'=> 'photo-img2',
    'before_widget'=> '',
    'after_widget'=> ''
));
register_sidebar(array (
    'name'=> 'Photo Body2',
    'id'=> 'photo-body2',
    'before_widget'=> '',
    'after_widget'=> ''
));

register_sidebar(array (
    'name'=> 'Photo Img3',
    'id'=> 'photo-img3',
    'before_widget'=> '',
    'after_widget'=> ''
));
register_sidebar(array (
    'name'=> 'Photo Body3',
    'id'=> 'photo-body3',
    'before_widget'=> '',
    'after_widget'=> ''
));


?>