<?php
wp_enqueue_style( 'style-name', get_stylesheet_uri() );
wp_enqueue_style( 'style-bootstrap', get_template_directory_uri() . './assets/css/bootstrap.min.css');

wp_enqueue_script( 'script-name', get_template_directory_uri() . './assets/js/bootstrap.bundle.min.js', array(), '1.0.0', true );

add_theme_support('title-tag');
add_theme_support('custom-logo');
add_theme_support('post-thumbnails');

register_sidebar(array(
    'name'=>'left-side',
    'id'=>'left-side',
    'before_widget'  => '',
	'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'right-side',
    'id'=>'right-side',
    'before_widget'  => '',
	'after_widget'   => "",
));

//header
register_sidebar(array(
    'name'=>'right-links1',
    'id'=>'right-links1',
    'before_widget'  => '',
	'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'right-links',
    'id'=>'right-links',
    'before_widget'  => '',
	'after_widget'   => "",
));

//menu
register_nav_menus(array(
    'TM'=>'Primary'
));

//banner
register_sidebar(array(
    'name'=>'banner',
    'id'=>'banner',
    'before_widget'  => '',
	'after_widget'   => "",
));




//sidebar
register_sidebar(array(
    'name'=>'sidebar',
    'id'=>'sidebar',
    'before_widget'  => '',
	'after_widget'   => "",
));

//জনপ্রিয় সেবা
register_sidebar(array(
    'name'=>'tab1-1',
    'id'=>'tab1-1',
    'before_widget'  => '',
	'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'tab1-2',
    'id'=>'tab1-2',
    'before_widget'  => '',
	'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'tab1-3',
    'id'=>'tab1-3',
    'before_widget'  => '',
	'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'tab1-4',
    'id'=>'tab1-4',
    'before_widget'  => '',
	'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'tab1-5',
    'id'=>'tab1-5',
    'before_widget'  => '',
	'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'tab1-6',
    'id'=>'tab1-6',
    'before_widget'  => '',
	'after_widget'   => "",
));

// lists
register_sidebar(array(
    'name'=>'lists',
    'id'=>'lists',
    'before_widget'  => '',
	'after_widget'   => "",
));
// tab
register_sidebar(array(
    'name'=>'tab1',
    'id'=>'tab1',
    'before_widget'  => '',
	'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'tab2',
    'id'=>'tab2',
    'before_widget'  => '',
	'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'tab3',
    'id'=>'tab3',
    'before_widget'  => '',
	'after_widget'   => "",
));

// mujib
register_sidebar(array(
    'name'=>'mujib',
    'id'=>'mujib',
    'before_widget'  => '',
	'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'mujib-v',
    'id'=>'mujib-v',
    'before_widget'  => '',
	'after_widget'   => "",
));
// mask
register_sidebar(array(
    'name'=>'mask',
    'id'=>'mask',
    'before_widget'  => '',
	'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'mask-v',
    'id'=>'mask-v',
    'before_widget'  => '',
	'after_widget'   => "",
));
// hasina
register_sidebar(array(
    'name'=>'hasina',
    'id'=>'hasina',
    'before_widget'  => '',
	'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'hasina-v',
    'id'=>'hasina-v',
    'before_widget'  => '',
	'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'hasina-v1',
    'id'=>'hasina-v1',
    'before_widget'  => '',
	'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'hasina-v2',
    'id'=>'hasina-v2',
    'before_widget'  => '',
	'after_widget'   => "",
));

//card
register_sidebar(array(
    'name'=>'card-v1',
    'id'=>'card-v1',
    'before_widget'  => '',
	'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'card-d',
    'id'=>'card-d',
    'before_widget'  => '',
	'after_widget'   => "",
));
//card
register_sidebar(array(
    'name'=>'card-v2',
    'id'=>'card-v2',
    'before_widget'  => '',
	'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'card-d2',
    'id'=>'card-d2',
    'before_widget'  => '',
	'after_widget'   => "",
));
//card
register_sidebar(array(
    'name'=>'card-v3',
    'id'=>'card-v3',
    'before_widget'  => '',
	'after_widget'   => "",
));
register_sidebar(array(
    'name'=>'card-d3',
    'id'=>'card-d3',
    'before_widget'  => '',
	'after_widget'   => "",
));


//top-footer
register_sidebar(array(
    'name'=>'Top-footer',
    'id'=>'top-footer',
    'before_widget'  => '',
	'after_widget'   => '',
));

//right-footer
register_sidebar(array(
    'name'=>'Right-footer',
    'id'=>'right-footer',
    'before_widget'  => '',
	'after_widget'   => '',
));

//menu2
register_nav_menus(array(
    'TM2' => 'Primary'
));







?>