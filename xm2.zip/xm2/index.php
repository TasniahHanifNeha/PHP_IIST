<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <?php wp_head();?>
</head>
<body>
    
<!-- ============header============= -->
<header class="cont">
    <div class="row header">
        <div class="col-lg-6"><?php dynamic_sidebar('left-side');?></div>
        <div class="col-lg-6 right-side d-flex justify-content-end"><?php dynamic_sidebar('right-side');?></div>
    </div>
</header>

<!-- ========header========= -->

<section class="cont logo pt-2">
    <div class="row">
        <div class="col-lg-4"><?php the_custom_logo();?></div>
        <div class="col-lg-5 search1 mt-4">
            <form action="">
                <input type="text" placeholder='search'>
                <button>Find</button>
            </form>
        </div>
        <div class="col-lg-1 mt-4 right-links1 text-end"><?php dynamic_sidebar('right-links1');?></div>
        <div class="col-lg-2 mt-4 right-links text-end"><?php dynamic_sidebar('right-links');?></div>
    </div>
</section>

<!-- =========menu========= -->
<section class="cont menu1">
    <?php wp_nav_menu(array(
        'theme-location'=>'TM'
    ));
    ?>
</section>

<!-- ========hero========= -->

<section class="cont hero mt-3">
    <div class="row">
        <div class="col-lg-8">
            <!-- =========banner========== -->
            <div class="banner">
                <?php dynamic_sidebar('banner');?>
            </div>

            <!-- ================slider============ -->
            <div class="slider1">
                <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <?php
                    $x==0;
                    while(have_posts()){the_post();
                    $x++;
                    ?>
                    <div class="carousel-item <?= ($x==1)? 'active' : '' ?>">
                    <?php the_post_thumbnail();?>
                    </div>
                    <?php }?>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
                </div>
            </div>

            <!-- ==============tab=================== -->
            <div class="tab1 mt-4">
                <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">জনপ্রিয় সেবা</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">নতুন সেবা</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">মোবাইল সেবা</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">দপ্তর ভিত্তিক সেবা</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">সকল ই-সেবা</button>
                </li>
                
                
                </ul>
                <div class="tab-content" id="pills-tabContent">
                <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0">
                    <!-- জনপ্রিয় সেবা -->
                    <div class="row">
                        <div class="col-lg-2">
                        <?php dynamic_sidebar('tab1-1');?>
                        </div>
                        <div class="col-lg-2">
                        <?php dynamic_sidebar('tab1-2');?>
                        </div>
                        <div class="col-lg-2">
                        <?php dynamic_sidebar('tab1-3');?>
                        </div>
                        <div class="col-lg-2">
                        <?php dynamic_sidebar('tab1-4');?>
                        </div>
                        <div class="col-lg-2">
                        <?php dynamic_sidebar('tab1-5');?>
                        </div>
                        <div class="col-lg-2">
                        <?php dynamic_sidebar('tab1-6');?>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-2">
                        <?php dynamic_sidebar('tab1-1');?>
                        </div>
                        <div class="col-lg-2">
                        <?php dynamic_sidebar('tab1-1');?>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabindex="0">...</div>
                <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab" tabindex="0">...</div>
                <div class="tab-pane fade" id="pills-disabled" role="tabpanel" aria-labelledby="pills-disabled-tab" tabindex="0">...</div>
                </div>
            </div>

            <!-- ===========lists============= -->

            <div class="lists mt-4">
                <?php dynamic_sidebar('lists');?>
            </div>  

            <!-- =========more-tab=========== -->
            <div class="more-tab mt-4">
                <div class="row">
                    <div class="col-lg-4"><?php dynamic_sidebar('tab1');?></div>
                    <div class="col-lg-4"><?php dynamic_sidebar('tab2');?></div>
                    <div class="col-lg-4"><?php dynamic_sidebar('tab3');?></div>
                </div>
            </div>
            
            <!-- ==========hasina====== -->

            <div class="hasina mt-4">
                <div class="hasina"><?php dynamic_sidebar('hasina');?></div>
                <div class="row">
                    <div class="col-lg-4"><?php dynamic_sidebar('hasina-v');?></div>
                    <div class="col-lg-4"><?php dynamic_sidebar('hasina-v1');?></div>
                    <div class="col-lg-4"><?php dynamic_sidebar('hasina-v1');?></div>
                </div>
            </div>

            <!-- ============card-tab========== -->

            <div class="card-v">
                <div class="row">
                    <h6>অন্যান্য ভিডিও</h6>
                    <div class="col-lg-4">
                        <div class="card" style="width: 14rem;height:3rem;">
                        <?php dynamic_sidebar('card-v1');?>
                            <div class="card-body">
                            <?php dynamic_sidebar('card-d');?>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card" style="width: 14rem;">
                        <?php dynamic_sidebar('card-v2');?>
                            <div class="card-body">
                            <?php dynamic_sidebar('card-d2');?>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="card" style="width: 14rem;">
                        <?php dynamic_sidebar('card-v3');?>
                            <div class="card-body">
                            <?php dynamic_sidebar('card-d3');?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>




        </div>

        














        <div class="col-lg-4">
            <!-- =========sidebar========== -->
            <div class="sidebar">
                <?php dynamic_sidebar('sidebar');?>
            </div>

            <!-- =========option======== -->

            <div class="option pt-3">
                <h4>সকল বাতায়ন</h4>
                <select name="" id="">
                    <option value="">ওয়েবসাইট বাছাই করুন</option>
                    <option value="">মন্ত্রণালয়</option>
                </select>
            </div>
                        
            <!-- =======mujib========== -->

            <div class="mujib mt-3">
            <?php dynamic_sidebar('mujib');?>
            <?php dynamic_sidebar('mujib-v');?>
            </div>

            <!-- =======mask========== -->

            <div class="mask mt-3">
            <?php dynamic_sidebar('mask');?>
            <?php dynamic_sidebar('mask-v');?>
            </div>
            <!-- =======mujib========== -->

            <div class="mujib mt-3">
            <?php dynamic_sidebar('mujib');?>
            <?php dynamic_sidebar('mujib-v');?>
            </div>

            <!-- =======mask========== -->

            <div class="mask mt-3">
            <?php dynamic_sidebar('mask');?>
            <?php dynamic_sidebar('mask-v');?>
            </div>



        </div>
    </div>
</section>




<!-- =====footer====== -->

<section>
    <div class="cont">
        <div class="row">
        <?php dynamic_sidebar('top-footer');?>
        </div>

        <div class="row">
            <div class="col-lg-6 menu-2">
                <?php wp_nav_menu( array(
                'theme_location'       => 'TM2',
                ))?>
                <p>সাইটটি শেষ হাল-নাগাদ করা হয়েছে: ২০২৩-০১-২৬ ০৭:৫২:৪০</p>
            </div>
            <!-- === -->
            <div class="col-lg-6 right-footer text-end">
                <p>পরিকল্পনা ও বাস্তবায়নে: এটুআই, মন্ত্রিপরিষদ বিভাগ, বিসিসি, বেসিস, ডিওআইসিটি</p>
                <?php dynamic_sidebar('right-footer');?>
            </div>



        </div>
    </div>
</section>




<?php wp_footer();?>
</body>
</html>