
<!-- ==========footer========== -->

<!-- <footer class="footer_part">
  <div class="row">
    <div class="col-sm-6 f-left">
    //dynamic_sidebar('f-left');
    </div>

    <div class="col-sm-6 f-right">
      //dynamic_sidebar('f-right');
    </div>
  </div>
</footer> -->

<footer class="footer_part">
  <div class="row upper_footer">
    <div class="col-sm-6 f-left">
      
      <ul>
        <h4>CONTACT US</h4>
        <li><a href="">Address: Office of the Project Director<br> Padma Multipurpose Bridge Project<br>
        4th floor, Setu Bhaban, New Airport<br> Road, Banani, Dhaka-1212</a></li>
        <li><a href="">Telephone: +880 2 55040451</a></li>
        <li><a href="">Fax: +880 2 55040477</a></li>
        <li><a href="">Email: padmabridgeweb@gmail.com</a></li>
      </ul>

    </div>
    
    <div class="col-sm-6 f-right">
      
      <ul>
        <h4>IMPORTANT LINKS</h4>
        <li><a href="">Prime Minister's Office</a></li>
        <li><a href="">PMIS</a></li>
        <li><a href="">Bangladesh Bridge Authority</a></li>
        <li><a href="">Bridges Division</a></li>
        <li><a href="">Roads and Highways Department</a></li>
        <li><a href="">Cabinet Division</a></li>
        <li><a href="">Ministry of Public Administration</a></li>
        <li><a href="">National Web Portal</a></li>
      </ul>
    </div>

    
  </div>
  
  <div class="row lower_footer">
    <div class="col-sm-6">
      <p>POWERED BY SOLUTION ART LTD</p>
    </div>
    <div class="col-sm-6">
      <p>COPYRIGHT © 2015. BANGLADESH BRIDGE AUTHORITY.</p>
    </div>
  </div>
</footer>
<?php wp_footer();?>
</body>
</html>

