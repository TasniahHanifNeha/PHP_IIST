<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <?php wp_head();?>
</head>
<body>



<!-- slider part start-->
<div class="container-fluid slider">
  <div class="logo">
  <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
    <?php
    $x = 0;
    while(have_posts()){the_post();
    $x++;
    ?>
    <div class="carousel-item <?=($x==1)? 'active': '' ?>">
        <?php the_post_thumbnail();?>
    </div>
    <?php }?>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>
</div>
  </div>
</div>
<!-- slider part start-->

<!-- ---logo part start---- -->
<section class="logo container-fluid pt-2">
    <div class="row">
        <div class="col-sm-6 logo-left">
            <?php the_custom_logo();?>
        </div>
        <div class="col-sm-6 logo-right text-end">
            <?php dynamic_sidebar('bdlogo');?>
        </div>
    </div>
</section>
<!-- ---logo part end---- -->

<!-- ---menu part start---  -->
<div class="container navbar-expand menu-1">

  <?php wp_nav_menu(array(
    'theme_location'=>'TM',
    'menu_class'=>'menu navbar-nav'
  ));

  ?>
</div>
<!-- ---menu part end---  -->

<!-- --hero part start--  -->
<div class="container text-center">
  <div class="row hero-top ">
  <?php dynamic_sidebar('herotop');?>
  </div>
  
  <div class="row hero-bottom ">
    <div class="col-sm-4">
      <div class="card" style="width: 18rem;">
      <?php dynamic_sidebar('herobottomimg');?>
      <div class="card-body">
      <?php dynamic_sidebar('herobody');?>
      </div>
      </div>
    </div>

    <div class="col-sm-4">
      <div class="card" style="width: 18rem;">
      <?php dynamic_sidebar('herobottomimg2');?>
      <div class="card-body">
      <?php dynamic_sidebar('herobody2');?>
      </div>
      </div>
    </div>

    <div class="col-sm-4">
      <div class="card" style="width: 18rem;">
      <?php dynamic_sidebar('herobottomimg3');?>
      <div class="card-body">
      <?php dynamic_sidebar('herobody3');?>
      </div>
      </div>
    </div>


  </div>
</div>
<!-- --hero part end--  -->


<!-- photo part start -->
<section class="container photo mt-5 text-center">
    <div class="row photo_top">
        <div class="col-sm-4">
            <!-- --------------------------------- -->
            <img src="<?= get_template_directory_uri()?>./assets/images/green3.png" alt="">
        </div>
        <div class="col-sm-4">
            <h4>Recent Photos</h4>
            <p>Lorem ipsum dolor sit amet</p>
        </div>
        <div class="col-sm-4">
        <img src="<?= get_template_directory_uri()?>./assets/images/green2.png" alt="">
        </div>
    </div>

    <div class="row photo-bottom">
      <div class="col-sm-3">
      <div class="card" style="width: 18rem;">
      <?php dynamic_sidebar('p-img1');?>
        <div class="card-body">
        <?php dynamic_sidebar('p-body1');?>
        </div>
      </div>
      </div>
      
    </div>

    <div class="row photo_end pt-5">
        <div class="col-sm-4">
            <!-- --------------------------------- -->
            <img src="<?= get_template_directory_uri()?>./assets/images/green3.png" alt="">
        </div>
        <div class="col-sm-4">
            <h4>NEWS & EVENTS</h4>
            <p>Lorem ipsum dolor sit amet</p>
        </div>
        <div class="col-sm-4">
        <img src="<?= get_template_directory_uri()?>./assets/images/green2.png" alt="">
        </div>
    </div>

</section>










<!-- --------------text-slider------------- -->

<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <?php
            $x=0;
            while(have_posts()){ the_post();
            $x++;
            ?>
            <div class="carousel-item <?= ($x==1)?'active': '' ?> ">
                <?php the_title(); ?>
                
            </div>
            <?php } ?>

        </div>
        
    </div>

<!-- ==========footer========== -->

<!-- <footer class="footer_part">
  <div class="row">
    <div class="col-sm-6 f-left">
    //dynamic_sidebar('f-left');
    </div>

    <div class="col-sm-6 f-right">
      //dynamic_sidebar('f-right');
    </div>
  </div>
</footer> -->

<footer class="footer_part">
  <div class="row upper_footer">
    <div class="col-sm-6 f-left">
      
      <ul>
        <h4>CONTACT US</h4>
        <li><a href="">Address: Office of the Project Director<br> Padma Multipurpose Bridge Project<br>
        4th floor, Setu Bhaban, New Airport<br> Road, Banani, Dhaka-1212</a></li>
        <li><a href="">Telephone: +880 2 55040451</a></li>
        <li><a href="">Fax: +880 2 55040477</a></li>
        <li><a href="">Email: padmabridgeweb@gmail.com</a></li>
      </ul>

    </div>
    
    <div class="col-sm-6 f-right">
      
      <ul>
        <h4>IMPORTANT LINKS</h4>
        <li><a href="">Prime Minister's Office</a></li>
        <li><a href="">PMIS</a></li>
        <li><a href="">Bangladesh Bridge Authority</a></li>
        <li><a href="">Bridges Division</a></li>
        <li><a href="">Roads and Highways Department</a></li>
        <li><a href="">Cabinet Division</a></li>
        <li><a href="">Ministry of Public Administration</a></li>
        <li><a href="">National Web Portal</a></li>
      </ul>
    </div>

    
  </div>
  
  <div class="row lower_footer">
    <div class="col-sm-6">
      <p>POWERED BY SOLUTION ART LTD</p>
    </div>
    <div class="col-sm-6">
      <p>COPYRIGHT © 2015. BANGLADESH BRIDGE AUTHORITY.</p>
    </div>
  </div>
</footer>






















<?php wp_footer();?>
</body>
</html>